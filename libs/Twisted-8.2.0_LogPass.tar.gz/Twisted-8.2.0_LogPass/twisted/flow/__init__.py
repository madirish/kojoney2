
# Copyright (c) 2001-2004 Twisted Matrix Laboratories.
# See LICENSE for details.

#
# Author: Clark C. Evans

"""
Twisted Flow: Generator support for data flows

This package is unmaintained.  It does not represent current best practices
for development with Twisted.  Use it with this in mind.
"""

__version__ = 'SVN-Trunk'

import warnings
warnings.warn("twisted.flow is unmaintained.", DeprecationWarning, 2)
