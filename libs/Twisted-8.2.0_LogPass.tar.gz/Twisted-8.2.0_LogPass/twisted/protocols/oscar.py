from twisted.python import util

util.moduleMovedForSplit('twisted.protocols.oscar', 'twisted.words.protocols.oscar',
                         'OSCAR protocol support', 'Words',
                         'http://twistedmatrix.com/trac/wiki/TwistedWords',
                         globals())

